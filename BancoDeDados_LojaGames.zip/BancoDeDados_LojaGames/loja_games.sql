CREATE DATABASE loja_games;
USE loja_games;

CREATE TABLE clientes (
    id_cliente INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    telefone VARCHAR(20)
);

CREATE TABLE funcionarios (
    id_funcionario INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cargo VARCHAR(50) NOT NULL,
    salario DECIMAL(10,2) NOT NULL
);

CREATE TABLE produtos (
    id_produto INT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    categoria VARCHAR(50) NOT NULL,
    preco DECIMAL(10,2) NOT NULL,
    estoque INT NOT NULL
);

CREATE TABLE pedidos (
    id_pedido INT PRIMARY KEY,
    id_cliente INT NOT NULL,
    id_funcionario INT NOT NULL,
    data_pedido DATE NOT NULL,
    status_pedido VARCHAR(30) NOT NULL,
    FOREIGN KEY (id_cliente) REFERENCES clientes(id_cliente),
    FOREIGN KEY (id_funcionario) REFERENCES funcionarios(id_funcionario)
);

CREATE TABLE itens_pedido (
    id_item INT PRIMARY KEY,
    id_pedido INT NOT NULL,
    id_produto INT NOT NULL,
    quantidade INT NOT NULL,
    FOREIGN KEY (id_pedido) REFERENCES pedidos(id_pedido),
    FOREIGN KEY (id_produto) REFERENCES produtos(id_produto)
);

INSERT INTO clientes (id_cliente, nome, email, telefone) VALUES
(1, 'Cliente 1', 'cliente1@email.com', '11999990001'),
(2, 'Cliente 2', 'cliente2@email.com', '11999990002'),
(3, 'Cliente 3', 'cliente3@email.com', '11999990003'),
(4, 'Cliente 4', 'cliente4@email.com', '11999990004'),
(5, 'Cliente 5', 'cliente5@email.com', '11999990005'),
(6, 'Cliente 6', 'cliente6@email.com', '11999990006'),
(7, 'Cliente 7', 'cliente7@email.com', '11999990007'),
(8, 'Cliente 8', 'cliente8@email.com', '11999990008'),
(9, 'Cliente 9', 'cliente9@email.com', '11999990009'),
(10, 'Cliente 10', 'cliente10@email.com', '11999990010'),
(11, 'Cliente 11', 'cliente11@email.com', '11999990011'),
(12, 'Cliente 12', 'cliente12@email.com', '11999990012'),
(13, 'Cliente 13', 'cliente13@email.com', '11999990013'),
(14, 'Cliente 14', 'cliente14@email.com', '11999990014'),
(15, 'Cliente 15', 'cliente15@email.com', '11999990015'),
(16, 'Cliente 16', 'cliente16@email.com', '11999990016'),
(17, 'Cliente 17', 'cliente17@email.com', '11999990017'),
(18, 'Cliente 18', 'cliente18@email.com', '11999990018'),
(19, 'Cliente 19', 'cliente19@email.com', '11999990019'),
(20, 'Cliente 20', 'cliente20@email.com', '11999990020'),
(21, 'Cliente 21', 'cliente21@email.com', '11999990021'),
(22, 'Cliente 22', 'cliente22@email.com', '11999990022'),
(23, 'Cliente 23', 'cliente23@email.com', '11999990023'),
(24, 'Cliente 24', 'cliente24@email.com', '11999990024'),
(25, 'Cliente 25', 'cliente25@email.com', '11999990025'),
(26, 'Cliente 26', 'cliente26@email.com', '11999990026'),
(27, 'Cliente 27', 'cliente27@email.com', '11999990027'),
(28, 'Cliente 28', 'cliente28@email.com', '11999990028'),
(29, 'Cliente 29', 'cliente29@email.com', '11999990029'),
(30, 'Cliente 30', 'cliente30@email.com', '11999990030'),
(31, 'Cliente 31', 'cliente31@email.com', '11999990031'),
(32, 'Cliente 32', 'cliente32@email.com', '11999990032'),
(33, 'Cliente 33', 'cliente33@email.com', '11999990033'),
(34, 'Cliente 34', 'cliente34@email.com', '11999990034'),
(35, 'Cliente 35', 'cliente35@email.com', '11999990035'),
(36, 'Cliente 36', 'cliente36@email.com', '11999990036'),
(37, 'Cliente 37', 'cliente37@email.com', '11999990037'),
(38, 'Cliente 38', 'cliente38@email.com', '11999990038'),
(39, 'Cliente 39', 'cliente39@email.com', '11999990039'),
(40, 'Cliente 40', 'cliente40@email.com', '11999990040'),
(41, 'Cliente 41', 'cliente41@email.com', '11999990041'),
(42, 'Cliente 42', 'cliente42@email.com', '11999990042'),
(43, 'Cliente 43', 'cliente43@email.com', '11999990043'),
(44, 'Cliente 44', 'cliente44@email.com', '11999990044'),
(45, 'Cliente 45', 'cliente45@email.com', '11999990045'),
(46, 'Cliente 46', 'cliente46@email.com', '11999990046'),
(47, 'Cliente 47', 'cliente47@email.com', '11999990047'),
(48, 'Cliente 48', 'cliente48@email.com', '11999990048'),
(49, 'Cliente 49', 'cliente49@email.com', '11999990049'),
(50, 'Cliente 50', 'cliente50@email.com', '11999990050');

INSERT INTO funcionarios (id_funcionario, nome, cargo, salario) VALUES
(1, 'Funcionario 1', 'Vendedor', 1835.5),
(2, 'Funcionario 2', 'Atendente', 1871.0),
(3, 'Funcionario 3', 'Vendedor', 1906.5),
(4, 'Funcionario 4', 'Atendente', 1942.0),
(5, 'Funcionario 5', 'Vendedor', 1977.5),
(6, 'Funcionario 6', 'Atendente', 2013.0),
(7, 'Funcionario 7', 'Vendedor', 2048.5),
(8, 'Funcionario 8', 'Atendente', 2084.0),
(9, 'Funcionario 9', 'Vendedor', 2119.5),
(10, 'Funcionario 10', 'Atendente', 2155.0),
(11, 'Funcionario 11', 'Vendedor', 2190.5),
(12, 'Funcionario 12', 'Atendente', 2226.0),
(13, 'Funcionario 13', 'Vendedor', 2261.5),
(14, 'Funcionario 14', 'Atendente', 2297.0),
(15, 'Funcionario 15', 'Vendedor', 2332.5),
(16, 'Funcionario 16', 'Atendente', 2368.0),
(17, 'Funcionario 17', 'Vendedor', 2403.5),
(18, 'Funcionario 18', 'Atendente', 2439.0),
(19, 'Funcionario 19', 'Vendedor', 2474.5),
(20, 'Funcionario 20', 'Atendente', 2510.0),
(21, 'Funcionario 21', 'Vendedor', 2545.5),
(22, 'Funcionario 22', 'Atendente', 2581.0),
(23, 'Funcionario 23', 'Vendedor', 2616.5),
(24, 'Funcionario 24', 'Atendente', 2652.0),
(25, 'Funcionario 25', 'Vendedor', 2687.5),
(26, 'Funcionario 26', 'Atendente', 2723.0),
(27, 'Funcionario 27', 'Vendedor', 2758.5),
(28, 'Funcionario 28', 'Atendente', 2794.0),
(29, 'Funcionario 29', 'Vendedor', 2829.5),
(30, 'Funcionario 30', 'Atendente', 2865.0),
(31, 'Funcionario 31', 'Vendedor', 2900.5),
(32, 'Funcionario 32', 'Atendente', 2936.0),
(33, 'Funcionario 33', 'Vendedor', 2971.5),
(34, 'Funcionario 34', 'Atendente', 3007.0),
(35, 'Funcionario 35', 'Vendedor', 3042.5),
(36, 'Funcionario 36', 'Atendente', 3078.0),
(37, 'Funcionario 37', 'Vendedor', 3113.5),
(38, 'Funcionario 38', 'Atendente', 3149.0),
(39, 'Funcionario 39', 'Vendedor', 3184.5),
(40, 'Funcionario 40', 'Atendente', 3220.0),
(41, 'Funcionario 41', 'Vendedor', 3255.5),
(42, 'Funcionario 42', 'Atendente', 3291.0),
(43, 'Funcionario 43', 'Vendedor', 3326.5),
(44, 'Funcionario 44', 'Atendente', 3362.0),
(45, 'Funcionario 45', 'Vendedor', 3397.5),
(46, 'Funcionario 46', 'Atendente', 3433.0),
(47, 'Funcionario 47', 'Vendedor', 3468.5),
(48, 'Funcionario 48', 'Atendente', 3504.0),
(49, 'Funcionario 49', 'Vendedor', 3539.5),
(50, 'Funcionario 50', 'Atendente', 3575.0);

INSERT INTO produtos (id_produto, nome, categoria, preco, estoque) VALUES
(1, 'Teclado Mecânico 1', 'Hardware', 62.25, 11),
(2, 'Headset 2', 'Simulador', 74.6, 12),
(3, 'Controle 3', 'Acessório', 86.95, 13),
(4, 'Volante Simulador 4', 'Periférico', 99.3, 14),
(5, 'Monitor 5', 'Hardware', 111.65, 15),
(6, 'Cadeira Gamer 6', 'Simulador', 124.0, 16),
(7, 'SSD 7', 'Acessório', 136.35, 17),
(8, 'Memória RAM 8', 'Periférico', 148.7, 18),
(9, 'Webcam 9', 'Hardware', 161.05, 19),
(10, 'Mouse Gamer 10', 'Simulador', 173.4, 20),
(11, 'Teclado Mecânico 11', 'Acessório', 185.75, 21),
(12, 'Headset 12', 'Periférico', 198.1, 22),
(13, 'Controle 13', 'Hardware', 210.45, 23),
(14, 'Volante Simulador 14', 'Simulador', 222.8, 24),
(15, 'Monitor 15', 'Acessório', 235.15, 25),
(16, 'Cadeira Gamer 16', 'Periférico', 247.5, 26),
(17, 'SSD 17', 'Hardware', 259.85, 27),
(18, 'Memória RAM 18', 'Simulador', 272.2, 28),
(19, 'Webcam 19', 'Acessório', 284.55, 29),
(20, 'Mouse Gamer 20', 'Periférico', 296.9, 30),
(21, 'Teclado Mecânico 21', 'Hardware', 309.25, 31),
(22, 'Headset 22', 'Simulador', 321.6, 32),
(23, 'Controle 23', 'Acessório', 333.95, 33),
(24, 'Volante Simulador 24', 'Periférico', 346.3, 34),
(25, 'Monitor 25', 'Hardware', 358.65, 35),
(26, 'Cadeira Gamer 26', 'Simulador', 371.0, 36),
(27, 'SSD 27', 'Acessório', 383.35, 37),
(28, 'Memória RAM 28', 'Periférico', 395.7, 38),
(29, 'Webcam 29', 'Hardware', 408.05, 39),
(30, 'Mouse Gamer 30', 'Simulador', 420.4, 40),
(31, 'Teclado Mecânico 31', 'Acessório', 432.75, 41),
(32, 'Headset 32', 'Periférico', 445.1, 42),
(33, 'Controle 33', 'Hardware', 457.45, 43),
(34, 'Volante Simulador 34', 'Simulador', 469.8, 44),
(35, 'Monitor 35', 'Acessório', 482.15, 45),
(36, 'Cadeira Gamer 36', 'Periférico', 494.5, 46),
(37, 'SSD 37', 'Hardware', 506.85, 47),
(38, 'Memória RAM 38', 'Simulador', 519.2, 48),
(39, 'Webcam 39', 'Acessório', 531.55, 49),
(40, 'Mouse Gamer 40', 'Periférico', 543.9, 50),
(41, 'Teclado Mecânico 41', 'Hardware', 556.25, 51),
(42, 'Headset 42', 'Simulador', 568.6, 52),
(43, 'Controle 43', 'Acessório', 580.95, 53),
(44, 'Volante Simulador 44', 'Periférico', 593.3, 54),
(45, 'Monitor 45', 'Hardware', 605.65, 55),
(46, 'Cadeira Gamer 46', 'Simulador', 618.0, 56),
(47, 'SSD 47', 'Acessório', 630.35, 57),
(48, 'Memória RAM 48', 'Periférico', 642.7, 58),
(49, 'Webcam 49', 'Hardware', 655.05, 59),
(50, 'Mouse Gamer 50', 'Simulador', 667.4, 60);

INSERT INTO pedidos (id_pedido, id_cliente, id_funcionario, data_pedido, status_pedido) VALUES
(1, 2, 2, '2026-05-02', 'Enviado'),
(2, 3, 3, '2026-05-03', 'Entregue'),
(3, 4, 4, '2026-05-04', 'Cancelado'),
(4, 5, 5, '2026-05-05', 'Pago'),
(5, 6, 6, '2026-05-06', 'Enviado'),
(6, 7, 7, '2026-05-07', 'Entregue'),
(7, 8, 8, '2026-05-08', 'Cancelado'),
(8, 9, 9, '2026-05-09', 'Pago'),
(9, 10, 10, '2026-05-10', 'Enviado'),
(10, 11, 11, '2026-05-11', 'Entregue'),
(11, 12, 12, '2026-05-12', 'Cancelado'),
(12, 13, 13, '2026-05-13', 'Pago'),
(13, 14, 14, '2026-05-14', 'Enviado'),
(14, 15, 15, '2026-05-15', 'Entregue'),
(15, 16, 16, '2026-05-16', 'Cancelado'),
(16, 17, 17, '2026-05-17', 'Pago'),
(17, 18, 18, '2026-05-18', 'Enviado'),
(18, 19, 19, '2026-05-19', 'Entregue'),
(19, 20, 20, '2026-05-20', 'Cancelado'),
(20, 21, 21, '2026-05-21', 'Pago'),
(21, 22, 22, '2026-05-22', 'Enviado'),
(22, 23, 23, '2026-05-23', 'Entregue'),
(23, 24, 24, '2026-05-24', 'Cancelado'),
(24, 25, 25, '2026-05-25', 'Pago'),
(25, 26, 26, '2026-05-26', 'Enviado'),
(26, 27, 27, '2026-05-27', 'Entregue'),
(27, 28, 28, '2026-05-28', 'Cancelado'),
(28, 29, 29, '2026-05-01', 'Pago'),
(29, 30, 30, '2026-05-02', 'Enviado'),
(30, 31, 31, '2026-05-03', 'Entregue'),
(31, 32, 32, '2026-05-04', 'Cancelado'),
(32, 33, 33, '2026-05-05', 'Pago'),
(33, 34, 34, '2026-05-06', 'Enviado'),
(34, 35, 35, '2026-05-07', 'Entregue'),
(35, 36, 36, '2026-05-08', 'Cancelado'),
(36, 37, 37, '2026-05-09', 'Pago'),
(37, 38, 38, '2026-05-10', 'Enviado'),
(38, 39, 39, '2026-05-11', 'Entregue'),
(39, 40, 40, '2026-05-12', 'Cancelado'),
(40, 41, 41, '2026-05-13', 'Pago'),
(41, 42, 42, '2026-05-14', 'Enviado'),
(42, 43, 43, '2026-05-15', 'Entregue'),
(43, 44, 44, '2026-05-16', 'Cancelado'),
(44, 45, 45, '2026-05-17', 'Pago'),
(45, 46, 46, '2026-05-18', 'Enviado'),
(46, 47, 47, '2026-05-19', 'Entregue'),
(47, 48, 48, '2026-05-20', 'Cancelado'),
(48, 49, 49, '2026-05-21', 'Pago'),
(49, 50, 50, '2026-05-22', 'Enviado'),
(50, 1, 1, '2026-05-23', 'Entregue');

INSERT INTO itens_pedido (id_item, id_pedido, id_produto, quantidade) VALUES
(1, 1, 2, 2),
(2, 2, 3, 3),
(3, 3, 4, 4),
(4, 4, 5, 5),
(5, 5, 6, 1),
(6, 6, 7, 2),
(7, 7, 8, 3),
(8, 8, 9, 4),
(9, 9, 10, 5),
(10, 10, 11, 1),
(11, 11, 12, 2),
(12, 12, 13, 3),
(13, 13, 14, 4),
(14, 14, 15, 5),
(15, 15, 16, 1),
(16, 16, 17, 2),
(17, 17, 18, 3),
(18, 18, 19, 4),
(19, 19, 20, 5),
(20, 20, 21, 1),
(21, 21, 22, 2),
(22, 22, 23, 3),
(23, 23, 24, 4),
(24, 24, 25, 5),
(25, 25, 26, 1),
(26, 26, 27, 2),
(27, 27, 28, 3),
(28, 28, 29, 4),
(29, 29, 30, 5),
(30, 30, 31, 1),
(31, 31, 32, 2),
(32, 32, 33, 3),
(33, 33, 34, 4),
(34, 34, 35, 5),
(35, 35, 36, 1),
(36, 36, 37, 2),
(37, 37, 38, 3),
(38, 38, 39, 4),
(39, 39, 40, 5),
(40, 40, 41, 1),
(41, 41, 42, 2),
(42, 42, 43, 3),
(43, 43, 44, 4),
(44, 44, 45, 5),
(45, 45, 46, 1),
(46, 46, 47, 2),
(47, 47, 48, 3),
(48, 48, 49, 4),
(49, 49, 50, 5),
(50, 50, 1, 1);


-- Consultas básicas
SELECT * FROM clientes WHERE nome LIKE 'Cliente 1%';
SELECT nome, preco FROM produtos WHERE preco BETWEEN 100 AND 300;
SELECT categoria, COUNT(*) AS total_produtos FROM produtos GROUP BY categoria;
SELECT AVG(preco) AS media_precos FROM produtos;
SELECT SUM(estoque) AS estoque_total FROM produtos;

-- Consultas com JOIN
SELECT p.id_pedido, c.nome AS cliente, f.nome AS funcionario, p.data_pedido, p.status_pedido
FROM pedidos p
JOIN clientes c ON p.id_cliente = c.id_cliente
JOIN funcionarios f ON p.id_funcionario = f.id_funcionario;

SELECT p.id_pedido, c.nome AS cliente, pr.nome AS produto, i.quantidade, pr.preco,
       (i.quantidade * pr.preco) AS valor_total
FROM itens_pedido i
JOIN pedidos p ON i.id_pedido = p.id_pedido
JOIN clientes c ON p.id_cliente = c.id_cliente
JOIN produtos pr ON i.id_produto = pr.id_produto;

-- Consultas analíticas
SELECT c.nome AS cliente, SUM(i.quantidade * pr.preco) AS total_gasto
FROM clientes c
JOIN pedidos p ON c.id_cliente = p.id_cliente
JOIN itens_pedido i ON p.id_pedido = i.id_pedido
JOIN produtos pr ON i.id_produto = pr.id_produto
GROUP BY c.nome
ORDER BY total_gasto DESC;

SELECT pr.categoria, SUM(i.quantidade * pr.preco) AS faturamento_categoria
FROM produtos pr
JOIN itens_pedido i ON pr.id_produto = i.id_produto
GROUP BY pr.categoria
ORDER BY faturamento_categoria DESC;

SELECT f.nome AS funcionario, COUNT(p.id_pedido) AS pedidos_atendidos
FROM funcionarios f
LEFT JOIN pedidos p ON f.id_funcionario = p.id_funcionario
GROUP BY f.nome
ORDER BY pedidos_atendidos DESC;
